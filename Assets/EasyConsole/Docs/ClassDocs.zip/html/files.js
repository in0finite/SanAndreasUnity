var files =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "CircularBuffer.cs", "_circular_buffer_8cs.html", null ],
    [ "Console.cs", "_console_8cs.html", null ],
    [ "HelpAttribute.cs", "_help_attribute_8cs.html", null ]
];