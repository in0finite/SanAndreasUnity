var namespaces =
[
    [ "Homans", "namespace_homans.html", null ],
    [ "Homans.Console", "namespace_homans_1_1_console.html", "namespace_homans_1_1_console" ],
    [ "Homans.Containers", "namespace_homans_1_1_containers.html", "namespace_homans_1_1_containers" ]
];