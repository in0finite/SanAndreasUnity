var searchData=
[
  ['dequeue',['Dequeue',['../class_homans_1_1_containers_1_1_circular_buffer-g.html#a7eca440c79b585ea852b46084cf6dda5',1,'Homans::Containers::CircularBuffer-g']]]
];
