var searchData=
[
  ['lines',['Lines',['../class_console.html#a7f68437a137e99cbc0cd08c5d205ca7c',1,'Console']]]
];
